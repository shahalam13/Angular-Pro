import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-regular-tables",
  templateUrl: "./regular-tables.component.html",
  styleUrls: ["./regular-tables.component.css"]
})
export class RegularTablesComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
