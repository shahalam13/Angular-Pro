## [1.1.0] - 2020-03-04
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.0.1] - 2019-04-08
### Changes
- perfect scrollbar issue
- added fixed plugin

## [1.0.0] - 2019-02-08
### Initial Release
